﻿using System.Media;

namespace GITPRACTICE
{
    partial class RPG
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            NextMove = new Button();
            Tip = new Label();
            XPBar = new ProgressBar();
            XPLabel = new Label();
            LevelLabel = new Label();
            HPBar = new ProgressBar();
            StaminaBar = new ProgressBar();
            HPLabel = new Label();
            StaminaLabel = new Label();
            ThisStep = new Label();
            WhatHappend = new Label();
            Yes = new Button();
            No = new Button();
            BCL = new Label();
            GECL = new Label();
            BECL = new Label();
            SCL = new Label();
            NHCL = new Label();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            CoinsLabel = new Label();
            SuspendLayout();
            // 
            // NextMove
            // 
            NextMove.Location = new Point(636, -1);
            NextMove.Name = "NextMove";
            NextMove.Size = new Size(164, 48);
            NextMove.TabIndex = 0;
            NextMove.Text = "наступний хід";
            NextMove.UseVisualStyleBackColor = true;
            NextMove.Click += NextMove_Click;
            // 
            // Tip
            // 
            Tip.AutoSize = true;
            Tip.Location = new Point(270, 9);
            Tip.Name = "Tip";
            Tip.Size = new Size(223, 20);
            Tip.TabIndex = 1;
            Tip.Text = "дійди до 50 рівня щоб виграти";
            // 
            // XPBar
            // 
            XPBar.Location = new Point(12, 409);
            XPBar.Name = "XPBar";
            XPBar.Size = new Size(205, 29);
            XPBar.TabIndex = 2;
            // 
            // XPLabel
            // 
            XPLabel.AutoSize = true;
            XPLabel.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            XPLabel.Location = new Point(223, 409);
            XPLabel.Name = "XPLabel";
            XPLabel.Size = new Size(111, 29);
            XPLabel.TabIndex = 3;
            XPLabel.Text = "0/100 XP";
            // 
            // LevelLabel
            // 
            LevelLabel.AutoSize = true;
            LevelLabel.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            LevelLabel.Location = new Point(69, 377);
            LevelLabel.Name = "LevelLabel";
            LevelLabel.Size = new Size(104, 29);
            LevelLabel.TabIndex = 4;
            LevelLabel.Text = "рівень 0";
            // 
            // HPBar
            // 
            HPBar.Location = new Point(333, 377);
            HPBar.Name = "HPBar";
            HPBar.Size = new Size(205, 29);
            HPBar.TabIndex = 5;
            HPBar.Value = 50;
            // 
            // StaminaBar
            // 
            StaminaBar.Location = new Point(333, 412);
            StaminaBar.Name = "StaminaBar";
            StaminaBar.Size = new Size(205, 29);
            StaminaBar.TabIndex = 6;
            // 
            // HPLabel
            // 
            HPLabel.AutoSize = true;
            HPLabel.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            HPLabel.Location = new Point(535, 377);
            HPLabel.Name = "HPLabel";
            HPLabel.Size = new Size(124, 29);
            HPLabel.TabIndex = 7;
            HPLabel.Text = "50/100 HP";
            // 
            // StaminaLabel
            // 
            StaminaLabel.AutoSize = true;
            StaminaLabel.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            StaminaLabel.Location = new Point(535, 412);
            StaminaLabel.Name = "StaminaLabel";
            StaminaLabel.Size = new Size(167, 29);
            StaminaLabel.TabIndex = 8;
            StaminaLabel.Text = "0/100 стаміна";
            // 
            // ThisStep
            // 
            ThisStep.AutoSize = true;
            ThisStep.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ThisStep.Location = new Point(310, 94);
            ThisStep.Name = "ThisStep";
            ThisStep.Size = new Size(132, 31);
            ThisStep.TabIndex = 9;
            ThisStep.Text = "Цим ходом";
            // 
            // WhatHappend
            // 
            WhatHappend.AutoSize = true;
            WhatHappend.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            WhatHappend.Location = new Point(134, 125);
            WhatHappend.Name = "WhatHappend";
            WhatHappend.Size = new Size(496, 62);
            WhatHappend.TabIndex = 10;
            WhatHappend.Text = "оголосили нагороду за вашу голову! \r\nБажаєте заплатити за скасування полювання?";
            WhatHappend.Click += label2_Click;
            // 
            // Yes
            // 
            Yes.BackColor = Color.FromArgb(192, 255, 192);
            Yes.Location = new Point(134, 190);
            Yes.Name = "Yes";
            Yes.Size = new Size(164, 48);
            Yes.TabIndex = 11;
            Yes.Text = "да(-50 Коїнів, +5XP)";
            Yes.UseVisualStyleBackColor = false;
            // 
            // No
            // 
            No.BackColor = Color.FromArgb(255, 192, 192);
            No.Location = new Point(442, 190);
            No.Name = "No";
            No.Size = new Size(164, 48);
            No.TabIndex = 12;
            No.Text = "ні(+10% шанс бою, -2.5 другі шанси)";
            No.UseVisualStyleBackColor = false;
            // 
            // BCL
            // 
            BCL.AutoSize = true;
            BCL.Location = new Point(12, 14);
            BCL.Name = "BCL";
            BCL.Size = new Size(135, 20);
            BCL.TabIndex = 13;
            BCL.Text = "Battle Chance: 25%";
            // 
            // GECL
            // 
            GECL.AutoSize = true;
            GECL.Location = new Point(12, 34);
            GECL.Name = "GECL";
            GECL.Size = new Size(184, 20);
            GECL.TabIndex = 14;
            GECL.Text = "Good Event Chance: 12.5%";
            // 
            // BECL
            // 
            BECL.AutoSize = true;
            BECL.Location = new Point(12, 54);
            BECL.Name = "BECL";
            BECL.Size = new Size(173, 20);
            BECL.TabIndex = 15;
            BECL.Text = "Bad Event Chance: 12.5%";
            // 
            // SCL
            // 
            SCL.AutoSize = true;
            SCL.Location = new Point(12, 74);
            SCL.Name = "SCL";
            SCL.Size = new Size(130, 20);
            SCL.TabIndex = 16;
            SCL.Text = "Shop Chance: 25%";
            // 
            // NHCL
            // 
            NHCL.AutoSize = true;
            NHCL.Location = new Point(12, 94);
            NHCL.Name = "NHCL";
            NHCL.Size = new Size(216, 20);
            NHCL.TabIndex = 17;
            NHCL.Text = "Nothing Happend Chance: 25%";
            // 
            // CoinsLabel
            // 
            CoinsLabel.AutoSize = true;
            CoinsLabel.Location = new Point(12, 345);
            CoinsLabel.Name = "CoinsLabel";
            CoinsLabel.Size = new Size(85, 20);
            CoinsLabel.TabIndex = 18;
            CoinsLabel.Text = "Койни: 100";
            // 
            // RPG
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CoinsLabel);
            Controls.Add(NHCL);
            Controls.Add(SCL);
            Controls.Add(BECL);
            Controls.Add(GECL);
            Controls.Add(BCL);
            Controls.Add(No);
            Controls.Add(Yes);
            Controls.Add(WhatHappend);
            Controls.Add(ThisStep);
            Controls.Add(StaminaLabel);
            Controls.Add(HPLabel);
            Controls.Add(StaminaBar);
            Controls.Add(HPBar);
            Controls.Add(LevelLabel);
            Controls.Add(XPLabel);
            Controls.Add(XPBar);
            Controls.Add(Tip);
            Controls.Add(NextMove);
            Name = "RPG";
            Text = "Untitled RPG";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button NextMove;
        private Label Tip;
        private ProgressBar XPBar;
        private Label XPLabel;
        private Label LevelLabel;
        private ProgressBar HPBar;
        private ProgressBar StaminaBar;
        private Label HPLabel;
        private Label StaminaLabel;
        private Label ThisStep;
        private Label WhatHappend;
        private Button Yes;
        private Button No;
        private Label BCL;
        private Label GECL;
        private Label BECL;
        private Label SCL;
        private Label NHCL;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label CoinsLabel;
    }
}
